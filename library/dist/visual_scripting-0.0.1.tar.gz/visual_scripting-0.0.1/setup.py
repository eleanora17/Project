from setuptools import setup, find_packages

setup(
    name='visual_scripting',
    version='0.0.1',
    description='A sample Python automation package',
    author='Deeptesh Shet',
    author_email='deeptesh.shet.0000@gmail.com',
    packages=find_packages(exclude=['tests','.venv']),
    install_requires=['selenium', 'requests'],
)
