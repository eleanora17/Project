from visual_scripting import core

def get_url(url):
    core.driver.get(url)
