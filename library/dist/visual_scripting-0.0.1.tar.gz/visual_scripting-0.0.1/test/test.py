from visual_scripting.browser import browser_actions

browser_actions.go_to_url("https://www.google.com")