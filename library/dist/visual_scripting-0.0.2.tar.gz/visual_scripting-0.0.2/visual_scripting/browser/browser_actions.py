from visual_scripting.core import selenium_actions
from visual_scripting.common import initialize


global driver
    

def go_to_url(url:str, browser="firefox"):
    global driver
    driver=initialize.setup(browser)
    selenium_actions.get_url(url)

def verifyPresenceOfElement(element_name,attribute_name):
    field=selenium_actions.find_element_xpath(element_name,attribute_name)
    return field

def click(element_name,attribute_name):
   button=selenium_actions.find_element_xpath(element_name,attribute_name)
   button.click()